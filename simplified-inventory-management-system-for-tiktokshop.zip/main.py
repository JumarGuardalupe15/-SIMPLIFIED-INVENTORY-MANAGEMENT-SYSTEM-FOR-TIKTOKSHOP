class TiktokShop:
    def __init__(self, name, price, stock):
        self._name = name  # Encapsulation: Using underscore to indicate a protected attribute
        self._price = price
        self._stock = stock

    def sell(self, quantity):
        if quantity <= self._stock:
            self._stock -= quantity
            print(f"Sold {quantity} {self._name}(s).")
        else:
            print(f"Insufficient stock for {quantity} {self._name}(s). Only {self._stock} remaining.")

    def display_info(self):
        print(f"Name: {self._name}")
        print(f"Price: ₱{self._price:.2f}")
        print(f"Stock: {self._stock}")


class Outfit(TiktokShop):
    def __init__(self, name, price, stock, size):
        super().__init__(name, price, stock)
        self._size = size  
   
    def display_info(self):
        super().display_info()
        print(f"Size: {self._size}")


class Gadgets(TiktokShop):
    def __init__(self, name, price, stock, brandname):
        super().__init__(name, price, stock)
        self._brandname = brandname  
    
    def display_info(self):
        super().display_info()
        print(f"Brand: {self._brandname}")


outfits = Outfit("Knitted Vest", 350, 10, "M")
gadget = Gadgets("Cellphone", 12000, 5, "Redmi")

outfits.display_info()
gadget.display_info()

outfits.sell(2)
gadget.sell(3)

print("\nAfter Sales:")
outfits.display_info()
gadget.display_info()

#SPECIAL THANKS TO:
# JOSHI JIGNASA
# CHARLES OULLET
# FUTURE PROGRAMMER
# DATA FLAIR
# W3SCHOOLS